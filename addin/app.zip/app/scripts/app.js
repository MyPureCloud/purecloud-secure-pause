'use strict';

angular.module('app', []);